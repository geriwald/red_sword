package com.redsword.item;

import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2390;
import net.minecraft.class_3218;

public class RedSwordItem extends class_1792 {

    public RedSwordItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public void method_7873(class_1799 stack, class_1309 target, class_1309 attacker) {
        super.method_7873(stack, target, attacker);

        // Spawn redstone particles on hit
        class_1937 world = attacker.method_73183();
        if (world instanceof class_3218 serverWorld) {
            spawnRedstoneParticles(serverWorld, target);
        }
    }

    private void spawnRedstoneParticles(class_3218 world, class_1309 target) {
        double x = target.method_23317();
        double y = target.method_23318();
        double z = target.method_23321();

        // Red color (0xFF0000 = red in RGB)
        class_2390 redDust = new class_2390(0xFF0000, 1.5f);

        // Spawn multiple particles in a burst effect around the target
        for (int i = 0; i < 30; i++) {
            double offsetX = (world.field_9229.method_43058() - 0.5) * 2.0;
            double offsetY = world.field_9229.method_43058() * 2.0;
            double offsetZ = (world.field_9229.method_43058() - 0.5) * 2.0;

            world.method_65096(
                redDust,
                x + offsetX,
                y + offsetY,
                z + offsetZ,
                1,
                0.1, 0.1, 0.1,
                0.05
            );
        }

        // Add some extra particles going upward for dramatic effect
        for (int i = 0; i < 15; i++) {
            double offsetX = (world.field_9229.method_43058() - 0.5) * 1.0;
            double offsetZ = (world.field_9229.method_43058() - 0.5) * 1.0;

            world.method_65096(
                redDust,
                x + offsetX,
                y + 1.0,
                z + offsetZ,
                1,
                0.0, 0.5, 0.0,
                0.2
            );
        }
    }
}
