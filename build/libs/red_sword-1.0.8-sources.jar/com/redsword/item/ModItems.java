package com.redsword.item;

import com.redsword.RedSwordMod;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import java.util.function.Function;

public class ModItems {


    public static final class_1792 RED_SWORD = register(
            "red_sword",
            RedSwordItem::new,
            new class_1792.class_1793()
                    .method_7889(1)
                    .method_24359());

    private static class_1792 register(String name, Function<class_1792.class_1793, class_1792> factory, class_1792.class_1793 settings) {
        class_5321<class_1792> key = class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(RedSwordMod.MOD_ID, name));
        return class_2378.method_39197(class_7923.field_41178, key, factory.apply(settings.method_63686(key)));
    }

    public static void registerItems() {
        RedSwordMod.LOGGER.info("Registering items for " + RedSwordMod.MOD_ID);

        // Add to combat item group
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40202).register(entries -> {
            entries.method_45421(RED_SWORD);
        });
    }
}
