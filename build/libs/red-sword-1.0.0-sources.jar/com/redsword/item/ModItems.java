package com.redsword.item;

import com.redsword.RedSwordMod;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3481;
import net.minecraft.class_3489;
import net.minecraft.class_5321;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9886;
import java.util.function.Function;

public class ModItems {

    // Custom tool material for the red sword (based on netherite but better)
    public static final class_9886 RED_SWORD_MATERIAL = new class_9886(
        class_3481.field_49925,  // blocks it can't mine
        4000,  // durability
        10.0F, // mining speed
        199.0F, // attack damage bonus (100 hearts = 200 damage, minus 1 base = 199)
        25,    // enchantability
        class_3489.field_52387  // repair items
    );

    public static final class_1792 RED_SWORD = register(
        "red_sword",
        RedSwordItem::new,
        new class_1792.class_1793()
            .method_66333(RED_SWORD_MATERIAL, 199.0F, -2.4F)  // damage, attack speed
            .method_24359()
    );

    private static class_1792 register(String name, Function<class_1792.class_1793, class_1792> factory, class_1792.class_1793 settings) {
        class_5321<class_1792> key = class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(RedSwordMod.MOD_ID, name));
        return class_2378.method_39197(class_7923.field_41178, key, factory.apply(settings.method_63686(key)));
    }

    public static void registerItems() {
        RedSwordMod.LOGGER.info("Registering items for " + RedSwordMod.MOD_ID);

        // Add to combat item group
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40202).register(entries -> {
            entries.method_45421(RED_SWORD);
        });
    }
}
